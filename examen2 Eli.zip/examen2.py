#Examen 2
#Hecho por Elieth Mora
#Carné 2024163728

import tkinter as tk
from tkinter import messagebox

selec = ""

def crear_photoimage(datos_imagen):
    return tk.PhotoImage(data=datos_imagen)

def get_selection():
    global selec
    selected_pass = None
    selec = ""
    if pass3_btn.cget('relief') == 'sunken':
        selected_pass = 'JAGUAR'
        selec = "Jaguar"
    elif pass7_btn.cget('relief') == 'sunken':
        selected_pass = 'PERESOZO'
        selec = "Peresozo"
    elif pass30_btn.cget('relief') == 'sunken':
        selected_pass = 'CARIBLANCO'
        selec = "Cariblanco"
    elif pass60_btn.cget('relief') == 'sunken':
        selected_pass = 'BALLENA'
        selec = "Ballena"
    return selected_pass

def pay():
    selection = get_selection()
    if selection:
        if selection == 'JAGUAR':
            msg = 'Pase 3 - CRC 10000 / USD 20'
        elif selection == 'PERESOZO':
            msg = 'Pase 7 - CRC 25000 / USD 50'
        elif selection == 'CARIBLANCO':
            msg = 'Pase 30 - CRC 80000 / USD 150'
        elif selection == 'BALLENA':
            msg = 'Pase 60 - CRC 160000 / USD 300'
        messagebox.showinfo('Pago', msg)
        reset_selection()

def reset_selection():
    pass3_btn.config(relief='raised')
    pass7_btn.config(relief='raised')
    pass30_btn.config(relief='raised')
    pass60_btn.config(relief='raised')
    qr_label.config(image='')

def buy():
    global selec
    selection = get_selection()
    if selec == "Jaguar":
        show_qr(qrJ)
    elif selec == "Peresozo":
        show_qr(qrP)
    elif selec == "Cariblanco":
        show_qr(qrC)
    elif selec == "Ballena":
        show_qr(qrB)
    else:
        messagebox.showwarning('Advertencia', 'No ha seleccionado un pase.')

def show_qr(qr_image):
    qr_label.config(image=qr_image)

def toggle_selection(button):
    global selec
    if button.cget('relief') == 'sunken':
        button.config(relief='raised')
        reset_selection()
    else:
        reset_selection()
        button.config(relief='sunken')

root = tk.Tk()
root.title('Máquina Expendedora de Pases')
root.geometry('500x500')
root.configure(bg='#ADD8E6')  

main_container = tk.Frame(root, width=500, height=500, bg='#ADD8E6')
main_container.pack(fill='both', expand=True)


logo_title = tk.Label(main_container, text='Metro Pass', font=('Arial', 20, 'bold'), bg='#ADD8E6')
logo_title.pack(pady=10)

buy_btn = tk.Button(main_container, text='Comprar', font=('Arial', 14, 'bold'), bg='#4CAF50', fg='white', relief='raised', command=buy)
buy_btn.pack(pady=10)

def redimensionar_imagen(imagen, escala):
    return imagen.subsample(escala, escala)

pass3_img = tk.PhotoImage(file="pass3.png")
pass7_img = tk.PhotoImage(file="pass_7.png")
pass30_img = tk.PhotoImage(file="pass30.png")
pass60_img = tk.PhotoImage(file="pass60.png")
qrJ = tk.PhotoImage(file="qrJ.png")
qrP = tk.PhotoImage(file="qrP.png")
qrC = tk.PhotoImage(file="qrC.png")
qrB = tk.PhotoImage(file="qrB.png")
logo_img = tk.PhotoImage(file="logo.png")
if logo_img: logo_img = redimensionar_imagen(logo_img, 8)
logo_label = tk.Label(main_container, image=logo_img, bg='#ADD8E6')
logo_label.place(x=10, y=10)

if pass3_img: pass3_img = redimensionar_imagen(pass3_img, 7)
if pass7_img: pass7_img = redimensionar_imagen(pass7_img, 4)
if pass30_img: pass30_img = redimensionar_imagen(pass30_img, 4)
if pass60_img: pass60_img = redimensionar_imagen(pass60_img, 3)

pass_frame = tk.Frame(main_container, bg='#ADD8E6')
if pass3_img:
    pass3_btn = tk.Button(pass_frame, image=pass3_img, relief='raised', command=lambda: toggle_selection(pass3_btn))
    pass3_btn.pack(side='left', padx=2)
    pass3_price = tk.Label(pass_frame, text='CRC 10000\nUSD 20', font=('Arial', 8), bg='#ADD8E6')
    pass3_price.pack(side='left')

if pass7_img:
    pass7_btn = tk.Button(pass_frame, image=pass7_img, relief='raised', command=lambda: toggle_selection(pass7_btn))
    pass7_btn.pack(side='left', padx=2)
    pass7_price = tk.Label(pass_frame, text='CRC 25000\nUSD 50', font=('Arial', 8), bg='#ADD8E6')
    pass7_price.pack(side='left')

if pass30_img:
    pass30_btn = tk.Button(pass_frame, image=pass30_img, relief='raised', command=lambda: toggle_selection(pass30_btn))
    pass30_btn.pack(side='left', padx=2)
    pass30_price = tk.Label(pass_frame, text='CRC 80000\nUSD 150', font=('Arial', 8), bg='#ADD8E6')
    pass30_price.pack(side='left')

if pass60_img:
    pass60_btn = tk.Button(pass_frame, image=pass60_img, relief='raised', command=lambda: toggle_selection(pass60_btn))
    pass60_btn.pack(side='left', padx=2)
    pass60_price = tk.Label(pass_frame, text='CRC 160000\nUSD 300', font=('Arial', 8), bg='#ADD8E6')
    pass60_price.pack(side='left')

pass_frame.pack(pady=10)

pay_btn = tk.Button(main_container, text='Pagar', font=('Arial', 14, 'bold'), bg='#2196F3', fg='white', relief='raised', command=pay)
pay_btn.pack(pady=10)

qr_label = tk.Label(main_container, bg='#ADD8E6')
qr_label.pack(pady=20)

root.mainloop()
